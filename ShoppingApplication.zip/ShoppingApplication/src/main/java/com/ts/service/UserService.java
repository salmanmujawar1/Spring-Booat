package com.ts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ts.model.User;
import com.ts.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;

	public User getUser() {
		User u = new User(101L, "OnePlus12", 100, 100000);
		return u;
	}

	public User saveUser(User user) {
		return userRepository.save(user);

	}
	public List<User> getAllUser() {
		return userRepository.findAll();
	}
//	public User getUser(Long id) {
//		return userRepository.findById(id).get();
//	}

}
