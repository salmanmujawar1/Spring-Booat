package com.ts.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ts.model.User;
import com.ts.repository.UserRepository;
import com.ts.service.UserService;

@RestController
@CrossOrigin("*")
public class UserController {

	@Autowired
	UserRepository userRepository;
	@Autowired
	UserService userService;
	
//	@GetMapping("/msg")
//	public String msg() {
//		return "Welcome";
//	}
	@GetMapping("/usr1")
	public User usr() {
		User usr = userService.getUser();
		return usr;
	}
	@PostMapping("/save.user")
	public User saveUser(@RequestBody User user) {
		return userService.saveUser(user);
	}
	@GetMapping("/get.all.user")
	public List<User> getAllUser(){
		return userService.getAllUser();
	}
//	@GetMapping("/get.user")
//	public User getUser(@RequestParam("pid") Long pid) {
//		return userService.getUser(pid);
//	}

}
