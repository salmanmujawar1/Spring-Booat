package com.ts.service;

import java.util.List;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ts.model.Account;
import com.ts.model.User;
import com.ts.repository.AccountRepository;
import com.ts.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;
	@Autowired
	AccountRepository accountRepository;

	public String regUser(User user) {

		Optional<User> usr = userRepository.findByAadharOrPanOrEmail(user.getAadhar(), user.getPan(), user.getEmail());

		if (usr.isPresent()) {
			return "Error";
		}

		User u = userRepository.save(user);

		Account acc = new Account();

		// create instance of Random class
		Random rand = new Random();

		// Generate random integers in range 0 to 9999
		int accNo = rand.nextInt(10000);

		Optional<Account> accno = accountRepository.findByAccountNumber(accNo);

		while (accno.isPresent()) {
			accNo = rand.nextInt(10000);
		}

		acc.setAccountNumber(accNo);
		acc.setType("SAVING");
		acc.setBalance(0);
		acc.setUid(u);
		Account newAcc = accountRepository.save(acc);

		return "Account Created Successfully And Your Account Number is : " + newAcc.getAccountNumber();
	}

	public List<User> getAllUser() {
		return userRepository.findAll();
	}
}
