package com.ts.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ts.model.Account;

import jakarta.transaction.Transactional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
	
	public Optional<Account> findByAccountNumber(int accno);
	public Optional<Account> findBalanceById(Long uid);
	public Optional<Account> findaccById(Long uid);
	
	@Transactional
    @Modifying
    @Query("UPDATE Account a SET a.balance = :newBalance WHERE a.acc = :acc")
    void updateBalanceByAcc(@Param("acc") int acc, @Param("newBalance") int newBalance);
	
	public Optional<Account> findBalanceByAcc(int acc);
}
